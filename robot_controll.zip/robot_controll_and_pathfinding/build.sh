# bash script for building this program.

rm *.gch
gcc *.c *.h -Wall -lm -g
