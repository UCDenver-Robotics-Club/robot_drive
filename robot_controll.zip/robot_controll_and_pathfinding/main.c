//
//  main.c
//  robotNavigation
//
//  Created by Dillon Hall on 1/4/18.
//  Copyright © 2018 Dillon Hall. All rights reserved.
//
// compile with:  gcc *.c *.h -Wall -g -lm
// if you forget the LM thing you're going to foroget this
// NOTE: NOT MADE WITH WITH LOVE.

#include <stdio.h>
#include "move.h"
#include "movestack.h"
#include <assert.h> // assert is love assert is life

#ifdef DESKTOP

void printMove(vmove *m)
{
    printf("x: %i y: %i \n",m->x,m->y);
}

int main(int argc, const char * argv[])
{
    move_stack stacky;
    vmove a = makemove(56,5);
    vmove b = makemove(4,67);
    vmove c = makemove(98,7);
    vmove d = makemove(22,45);
    vmove e = makemove(-23,-4);
    // push all these nice vectors to a stack
    init_stack(&stacky);
    push(&a,&stacky);
    push(&b,&stacky);
    push(&c,&stacky);
    push(&d,&stacky);
    push(&e,&stacky);

    printstack(&stacky);

    // find the net displacement
    vmove netdis = findnetdisplacement(&stacky);
    // asserts to make sure that we have the correct value
    assert(netdis.x == 157);
    assert(netdis.y == 120);
    printMove(&netdis);

    return 0;
}

#endif
