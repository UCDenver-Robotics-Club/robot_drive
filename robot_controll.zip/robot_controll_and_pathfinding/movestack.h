//
//  movestack.h
//  robotNavigation
//
//  Created by Dillon Hall on 1/4/18.
//  Copyright © 2018 Dillon Hall. All rights reserved.
//

#ifndef movestack_h
#define movestack_h
#define STACKSIZE 80
#define DESKTOP

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include "move.h"

// stack that can keep track of the
typedef struct
{
    size_t top;
    vmove stackdata[STACKSIZE];
} move_stack;

void init_stack(move_stack *stack);
bool push(vmove *elem,move_stack *stack);
vmove pop(move_stack *stack);
vmove findnetdisplacement(const move_stack *stack); // totally needed

#ifdef DESKTOP
void printstack(move_stack *stack);
#endif

#endif /* movestack_h */
