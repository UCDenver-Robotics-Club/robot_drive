//
//  move.h
//  robotNavigation
//
//  Created by Dillon Hall on 1/4/18.
//  Copyright © 2018 Dillon Hall. All rights reserved.
//

#ifndef move_h
#define move_h
#define PI 3.14159265
#define RAD (180/PI) 

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

// basicly a vector for where the robot is going to move

typedef struct
{
    int16_t x;
    int16_t y;
    uint32_t id; // makes everything easier
} vmove; // basicly a vector

// rules, all vectors as prameters should be imutable and no values should be turned
// unless it makes things faster
// or it's really really funny

vmove makemove(int16_t new_x,int16_t new_y);

// add two vectors; pointer is immutable, but the value is not
vmove add(const vmove* a,const vmove* b);
// sub two vectors, same mojo jojo
vmove sub(const vmove* a,const vmove* b);
vmove sum(vmove *a,size_t numvectors); // sub all the vectors into 1 vector

bool equal(const vmove* a,const vmove* b);

float getangle(const vmove *v);
int16_t getlength(const vmove *v);
vmove reverse(const vmove *v);

// these are the only vector functions that I think we need to drive a robot... but you! yes you! should add
// more functions.
// then find some cool uses for them that I haven't thought of.  Ofcouse you could be me three days in the
// future, but right now I kindof like to think that someone will be going through this long after I've
// graduated and moved on to a less hectic, better life


#endif /* move_h */
