# robot_controll_and_pathfinding

robot control and path finding program.  This is just a simple vector math lib with some other stuff on it.

To use:

1. comment out the line in movestack.h "#define DESKTOP"
2. compress this folder as a .zip file
3. then in processing IDE, click on Sketch -> include library -> add .zip library
4. look for the name of this library in the contributed library section of the dropdown menu

  
