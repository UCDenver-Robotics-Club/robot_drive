//
//  move.c
//  robotNavigation
//
//  Created by Dillon Hall on 1/4/18.
//  Copyright © 2018 Dillon Hall. All rights reserved.
//

#include "move.h"

vmove makemove(int16_t new_x,int16_t new_y)
{
    vmove new_move;
    new_move.x = new_x;
    new_move.y = new_y;

    return new_move;
}

vmove add(const vmove* a,const vmove* b)
{
    vmove new_move;

    new_move.x = a->x + (*b).x; // hehe
    new_move.y = a->y + b->y;

    return new_move;
}

vmove sub(const vmove* a,const vmove* b)
{
    vmove new_move;

    new_move.x = a->x - b->x;
    new_move.y = a->y - b->y;

    return new_move;
}

vmove sum(vmove *a,size_t numvectors)
{
    vmove sum_moves;

    sum_moves.x = 0;
    sum_moves.y = 0;


    size_t i;
    for(i=0;i<numvectors;i++)
    {
        sum_moves. x += a[i].x;
        sum_moves. y += a[i].y;
    }

    return sum_moves;
}

bool equal(const vmove* a,const vmove* b)
{
    bool isqual = false;

    return isqual;
}

float getangle(const vmove *v)
{
  double x = (double)v->x;
  double y = (double)v->y;

  double tan_theta = y/x;

  double theta = atan(tan_theta)*RAD;

  return (float)theta;
}

int16_t getlength(const vmove *v)
{
  int16_t vlen = (v->x * v->x) + (v->y * v->y);

  vlen = sqrt((double)vlen);

  return vlen;
}

// reverse a vector
vmove reverse(const vmove *v)
{
  // double angle180 = 0.017453;
  // vmove unit180 = makemove(cos(angle180),sin(angle180));
  return makemove(v->x*-1,v->y*-1);
}
