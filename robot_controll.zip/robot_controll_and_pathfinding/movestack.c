//
//  movestack.c
//  robotNavigation
//
//  Created by Dillon Hall on 1/4/18.
//  Copyright © 2018 Dillon Hall. All rights reserved.
//

#include "movestack.h"

bool push(vmove *elem,move_stack *stack)
{
    bool success=true;

    if(stack->top >= STACKSIZE)
    {
        success = false;
    }
    else
    {
        stack->stackdata[stack->top] = *elem;
        stack->top = (stack->top) + 1;
    }

    return success;
}

vmove pop(move_stack *stack)
{
    vmove poped;

    if(stack->top < 1) // if less than zero
    {
        poped.x = 0;
        poped.y = 0;
    }
    else
    {
        poped.x = stack->stackdata[stack->top].x;
        poped.y = stack->stackdata[stack->top].y;
        stack->top = stack->top - 1;
    }

    return poped;
}

#ifdef DESKTOP
void printstack(move_stack *stack)
{
    uint8_t filled_elems=stack->top;

    if(filled_elems > 0)
    {
        uint8_t i;
        for(i=0;i<filled_elems;i++)
        {
            printf("frame: %d x: %d y: %d \n",i,stack->stackdata[i].x,stack->stackdata[i].y);
        }
    }
}
#endif

vmove findnetdisplacement(const move_stack *stack)
{
  vmove net_displacement;
  // inital values for net displacement
  net_displacement.x = 0;
  net_displacement.y = 0;

  size_t i;
  for(i=0;i<stack->top;i++)
  {
    net_displacement = add(&net_displacement,&(stack->stackdata[i]));
  }

  return net_displacement;
}

void init(move_stack *stack)
{
  stack -> top = 0;
  size_t i;
  for(i=0;i<STACKSIZE;i++)
  {
    vmove placeholder;
    placeholder.x = 0;
    placeholder.y = 0;
    stack->stackdata[i] = placeholder;
  }
}
